CREATE TABLE springboot.app_user
(
   id INTEGER,
   username VARCHAR (30),
   password VARCHAR (30)
);