INSERT INTO springboot.app_user(id, username, password) VALUES (100,"ranjith","sekar");
INSERT INTO springboot.app_user(id, username, password) VALUES (200,"spring","boot");
INSERT INTO springboot.app_user(id, username, password) VALUES (300,"tom","cat");