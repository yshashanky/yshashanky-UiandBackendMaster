package jbr.sboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbootSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbootSecurityApplication.class, args);
	}

}
